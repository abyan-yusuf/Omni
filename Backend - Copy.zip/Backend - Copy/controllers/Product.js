const Product = require("../models/Product");
const fs = require("fs");

exports.createProduct = async (req, res) => {
  try {
    const {
      name,
      code,
      description,
      originalPrice,
      discountPrice,
      bestSeller,
      featured,
      color,
      sizes,
      category,
      subCategory,
    } = req.fields;

    const { image1, image2 } = req.files;
    if (!name) return res.status(404).send({ message: "Name is required" });
    if (!code) return res.status(404).send({ message: "Code is required" });
    if (!description)
      return res.status(404).send({ message: "Description is required" });
    if (!originalPrice)
      return res.status(404).send({ message: "Original Price is required" });
    if (!category)
      return res.status(404).send({ message: "Category is required" });
    if (!subCategory)
      return res.status(404).send({ message: "Sub Category is required" });
    if (!image1)
      return res.status(404).send({ message: "Image 1 is required" });
    if (!image2)
      return res.status(404).send({ message: "Image 2 is required" });
    if (!color) return res.status(404).send({ message: "Color is required" });
    if (!sizes) return res.status(404).send({ message: "Sizes is required" });
    const existingProductByCode = await Product.findOne({ code });
    const existingProductByName = await Product.findOne({ name });
    if (existingProductByCode || existingProductByName)
      return res
        .status(500)
        .send({ message: "Product already exists by code or name" });

    const sizesArray = typeof sizes === "string" ? JSON.parse(sizes) : sizes;

    const newProduct = new Product({
      ...req.fields,
      sizes: sizesArray,
    });

    newProduct.image1.data = fs.readFileSync(image1.path);
    newProduct.image1.contentType = image1.type;
    newProduct.image2.data = fs.readFileSync(image2.path);
    newProduct.image2.contentType = image2.type;

    await newProduct.save();
    return res
      .status(200)
      .send({ message: "Product created successfully", newProduct });
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name,
      code,
      description,
      originalPrice,
      discountPrice,
      color,
      sizes,
      category,
      subCategory,
    } = req.fields;

    const { image1, image2 } = req.files;

    if (!name) return res.status(404).send({ message: "Name is required" });
    if (!code) return res.status(404).send({ message: "Code is required" });
    if (!description)
      return res.status(404).send({ message: "Description is required" });
    if (!originalPrice)
      return res.status(404).send({ message: "Original Price is required" });
    if (!discountPrice)
      return res.status(404).send({ message: "Discount Price is required" });
    if (!category)
      return res.status(404).send({ message: "Category is required" });
    if (!subCategory)
      return res.status(404).send({ message: "Sub Category is required" });
    if (!color) return res.status(404).send({ message: "Color is required" });
    if (!sizes) return res.status(404).send({ message: "Sizes is required" });

    const existingProduct = await Product.findById(id);
    if (!existingProduct)
      return res.status(500).send({ message: "Product does not exist" });

    const sizesArray = typeof sizes === "string" ? JSON.parse(sizes) : sizes;

    const data = {
      ...req.fields,
      sizes: sizesArray,
    };
    const updatedProduct = await Product.findByIdAndUpdate(id, data, {
      new: true,
    });

    if (image1?.path && image1?.type) {
      updatedProduct.image1.data = fs.readFileSync(image1.path);
      updatedProduct.image1.contentType = image1.type;
    }

    if (image2?.path && image2?.type) {
      updatedProduct.image2.data = fs.readFileSync(image2.path);
      updatedProduct.image2.contentType = image2.type;
    }

    await updatedProduct.save();

    if (!updatedProduct)
      return res.status(404).send({ message: "Product not found" });
    return res
      .status(200)
      .send({ message: "Product updated successfully", updatedProduct });
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};

exports.getAllProducts = async (req, res) => {
  try {
    res.status(200).json(await Product.find().select("-image1 -image2"));
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedProduct = await Product.findByIdAndDelete(id);
    if (!deletedProduct)
      return res.status(404).send({ message: "Product not found" });
    return res.status(200).send({ message: "Product deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};

exports.getProductImage = async (req, res) => {
  try {
    const { id } = req.params;
    const productImage = await Product.findById(id).select(`image1`);
    if (!productImage)
      return res.status(404).send({ message: "Product Image not found" });
    if (productImage.image1.data) {
      res.set("Content-Type", productImage.image1.contentType);
      return res.status(200).send(productImage.image1.data);
    }
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};

exports.getProductDetailsImage = async (req, res) => {
  try {
    const { id } = req.params;
    const productImage = await Product.findById(id).select(`image2`);
    if (!productImage)
      return res.status(404).send({ message: "Product Image not found" });
    if (productImage.image2.data) {
      res.set("Content-Type", productImage.image2.contentType);
      return res.status(200).send(productImage.image2.data);
    }
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};

exports.getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);
    if (!product) return res.status(404).send({ message: "Product not found" });
    return res.status(200).json(product);
  } catch (error) {
    console.error(error);
    res.status(500).send(error);
  }
};
